<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                Editar Revista
            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">

        </div>
    </div>
    <?php $edit = $data['actividad']->id; ?>
    <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-9">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('editar.editaracademica',['edit'=>$edit])->html();
} elseif ($_instance->childHasBeenRendered('NdaR26S')) {
    $componentId = $_instance->getRenderedChildComponentId('NdaR26S');
    $componentTag = $_instance->getRenderedChildComponentTagName('NdaR26S');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NdaR26S');
} else {
    $response = \Livewire\Livewire::mount('editar.editaracademica',['edit'=>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('NdaR26S', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

    <?php // $edit=$data['persona']->id;?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('borrar.borrar_actividadacademica',['edit' =>$edit])->html();
} elseif ($_instance->childHasBeenRendered('qVWQWeM')) {
    $componentId = $_instance->getRenderedChildComponentId('qVWQWeM');
    $componentTag = $_instance->getRenderedChildComponentTagName('qVWQWeM');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qVWQWeM');
} else {
    $response = \Livewire\Livewire::mount('borrar.borrar_actividadacademica',['edit' =>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('qVWQWeM', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/actividad_academica/edit.blade.php ENDPATH**/ ?>