<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                <?php echo e($data['articulo']->titulo); ?>

            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">
            
            <a href="/articulos/<?php echo e($data['articulo']->id); ?>/edit">
                <button type="button"
                    class="order-0 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:order-1 sm:ml-3">
                    Editar Artículo
                </button>
            </a>

        </div>
    </div>


    <div class="mt-6 sm:mt-2 2xl:mt-5">
        <div class="border-b border-gray-200">
            <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                    <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                    <a href="#"
                        class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                        aria-current="page">
                        Datos Principales
                    </a>
                    
                </nav>
            </div>
        </div>
    </div>

    <!-- Description list -->
    <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
        <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">


            <div class="sm:col-span-2">
                <dt class="text-sm font-medium text-gray-500">
                    Autores
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo $data['autores']; ?>

                </dd>
            </div>



            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Revista
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['revista']->nombre); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">

                <dt class="text-sm font-medium text-gray-500">
                    DOI
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->DOI); ?>

                </dd>

            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Estado de Publicación
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->estado_publicacion); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Año de Publicación
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->fecha_publicacion); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Intervalo de Páginas
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->intervalo_paginas); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Issue
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->issue); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Volumen
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['articulo']->volumen); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                
            </div>

            <div class="sm:col-span-2">
                
            </div>
        </dl>
    </div>

    

    <?php if(count($data['proyectos']) != 0): ?>

        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                        <a href="#"
                            class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">
                            Proyectos Relacionados
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Description list -->
        <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
            <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                <?php $__currentLoopData = $data['proyectos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-medium text-gray-500">
                            
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900">
                            <?php echo $proyecto; ?>

                            
                        </dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </dl>
        </div>
    <?php else: ?>
        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->

                        <div class=" text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">No hay Proyectos Relacionados</div>


                    </nav>
                </div>
            </div>
        </div>

    <?php endif; ?>

    <br><br>
    <hr>



    <?php if(count($data['tesis']) != 0): ?>

        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                        <a href="#"
                            class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">
                            Proyectos Relacionados
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Description list -->
        <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
            <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                <?php $__currentLoopData = $data['tesis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-medium text-gray-500">
                            
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900">
                            <?php echo $tesis->full_nameLink(); ?>. Autor: <?php echo $tesis->autor->full_nameLink(); ?>. Tutor: <?php echo $tesis->tutor_de_la_tesis->full_nameLink(); ?>.
                            <?php if(true): ?>
                                Cotutores: <?php echo $tesis->cotutores_de_la_tesis(); ?>

                            <?php endif; ?>
                            
                        </dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </dl>
        </div>

        <?php else: ?>
        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->

                        <div class=" text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">No hay Tesis Relacionadas</div>


                    </nav>
                </div>
            </div>
        </div>

    <?php endif; ?>



 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/articulos/show.blade.php ENDPATH**/ ?>