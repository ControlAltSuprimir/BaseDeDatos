<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Base de Datos</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" rel="stylesheet"
        type='text/css'>

    <?php echo \Livewire\Livewire::styles(); ?>


    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</head>
<div class="h-screen flex overflow-hidden bg-white">
    


    <div class="hidden lg:flex lg:flex-shrink-0">
        <div class="flex flex-col w-64 border-r border-gray-200 pt-5 pb-4 bg-gray-100">
            <div class="flex items-center flex-shrink-0 px-6">
                <a href="/dashboard">
                <img class="h-10 px-3 w-auto" 
                src="/img/logoBaner.png">

                
                </a>
            </div>
            <!-- Sidebar component, swap this element with another sidebar if you like -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('E76k0mD')) {
    $componentId = $_instance->getRenderedChildComponentId('E76k0mD');
    $componentTag = $_instance->getRenderedChildComponentTagName('E76k0mD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('E76k0mD');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('E76k0mD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <!-- Main column -->
    <main class="flex-1 relative z-0 overflow-y-auto focus:outline-none">
        <?php echo e($slot); ?>

    </main>
</div>

<?php echo $__env->yieldPushContent('modals'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/layouts/app.blade.php ENDPATH**/ ?>