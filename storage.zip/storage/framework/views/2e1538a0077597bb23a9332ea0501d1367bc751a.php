<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
      <div class="flex-1 min-w-0">
        <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
          Editar Proyecto
        </h1>
      </div>
      <div class="mt-4 flex sm:mt-0 sm:ml-4">
       
      </div>
    </div>
    <?php $edit=$data['id']; ?>
  <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-9">
       <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('editar.editarproyecto',['edit'=>$edit])->html();
} elseif ($_instance->childHasBeenRendered('Gz2LXog')) {
    $componentId = $_instance->getRenderedChildComponentId('Gz2LXog');
    $componentTag = $_instance->getRenderedChildComponentTagName('Gz2LXog');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Gz2LXog');
} else {
    $response = \Livewire\Livewire::mount('editar.editarproyecto',['edit'=>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('Gz2LXog', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

       <?php // $edit=$data['id'];?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('borrar.borrar_proyecto',['edit' =>$edit])->html();
} elseif ($_instance->childHasBeenRendered('UppCRQX')) {
    $componentId = $_instance->getRenderedChildComponentId('UppCRQX');
    $componentTag = $_instance->getRenderedChildComponentTagName('UppCRQX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UppCRQX');
} else {
    $response = \Livewire\Livewire::mount('borrar.borrar_proyecto',['edit' =>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('UppCRQX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
      
    </div>
   <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/proyectos/edit.blade.php ENDPATH**/ ?>