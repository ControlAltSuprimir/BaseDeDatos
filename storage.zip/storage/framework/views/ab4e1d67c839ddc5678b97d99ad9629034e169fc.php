<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                <?php echo e($data['proyecto']->titulo); ?>

            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">
            
            <a href="/proyectos/<?php echo e($data['proyecto']->id); ?>/edit">
                <button type="button"
                    class="order-0 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:order-1 sm:ml-3">
                    Editar Proyecto
                </button>
            </a>

        </div>
    </div>


    <div class="mt-6 sm:mt-2 2xl:mt-5">
        <div class="border-b border-gray-200">
            <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                    <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                    <a href="#"
                        class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                        aria-current="page">
                        Perfil
                    </a>
                    
                </nav>
            </div>
        </div>
    </div>

    <!-- Description list -->
    <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
        <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">

            <div class="sm:col-span-2">
                <dt class="text-sm font-medium text-gray-500">
                    Investigador Responsable
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo $data['proyecto']->responsable->full_name(); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Tipo Proyecto
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->tipo_proyecto); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">

                <dt class="text-sm font-medium text-gray-500">
                    Organización que Financia
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->organizacion_financia); ?>

                </dd>

            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Fecha Inicio
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->comienzo); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">

                <dt class="text-sm font-medium text-gray-500">
                    Fecha Término
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->termino); ?>

                </dd>

            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Monto Adjudicado
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->monto_adjudicado); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">

                <dt class="text-sm font-medium text-gray-500">
                    Código del Proyecto
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->codigo_proyecto); ?>

                </dd>

            </div>

            <div class="sm:col-span-1">
                <dt class="text-sm font-medium text-gray-500">
                    Área de Investigación
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->area); ?>

                </dd>
            </div>

            <div class="sm:col-span-1">

                <dt class="text-sm font-medium text-gray-500">
                    
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    
                </dd>

            </div>
            <hr>

            <div class="sm:col-span-2">
                <dt class="text-sm font-medium text-gray-500">
                    Descripción del Proyecto
                </dt>
                <dd class="mt-1 text-sm text-gray-900">
                    <?php echo e($data['proyecto']->descripcion); ?>

                </dd>
            </div>


        </dl>
    </div>
    <br><br>
    <hr>

    <?php if(count($data['articulos']) != 0): ?>

        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                        <a href="#"
                            class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">
                            Artículos Relacionados
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Description list -->
        <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
            <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                <?php $__currentLoopData = $data['articulos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-medium text-gray-500">
                            
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900">
                            <?php echo $articulo; ?>

                            
                        </dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </dl>
        </div>
    <?php else: ?>
        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->

                        <div class=" text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">No hay Artículos Relacionados</div>


                    </nav>
                </div>
            </div>
        </div>

    <?php endif; ?>

    <br><br>
    <hr>

    <?php if(count($data['tesis']) != 0): ?>

        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->
                        <a href="#"
                            class="border-pink-500 text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">
                            Tesis Relacionados
                        </a>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Description list -->
        <div class="mt-6 max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
            <dl class="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
                <?php $__currentLoopData = $data['tesis']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tesis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="sm:col-span-2">
                        <dt class="text-sm font-medium text-gray-500">
                            
                        </dt>
                        <dd class="mt-1 text-sm text-gray-900">
                            <?php echo $tesis; ?>

                            
                        </dd>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </dl>
        </div>
    <?php else: ?>
        <div class="mt-6 sm:mt-2 2xl:mt-5">
            <div class="border-b border-gray-200">
                <div class="max-w-12xl mx-auto px-4 sm:px-6 lg:px-8">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <!-- Current: "border-pink-500 text-gray-900", Default: "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" -->

                        <div class=" text-gray-900 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm"
                            aria-current="page">No hay Tesis Relacionados</div>


                    </nav>
                </div>
            </div>
        </div>

    <?php endif; ?>






 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/proyectos/show.blade.php ENDPATH**/ ?>