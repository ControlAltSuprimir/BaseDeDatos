<?php if($sortBy !== $field): ?>
<i  class=" text-muted fas fa-sort"></i>
<?php elseif($sortDirection == 'asc'): ?>
<i style="color:rgba(38, 38, 236, 0.774)" class="fas fa-sort-up"></i>
<?php else: ?>
<i style="color:rgba(38, 38, 236, 0.774)" class="fas fa-sort-down"></i>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/partials/_sort-icon.blade.php ENDPATH**/ ?>