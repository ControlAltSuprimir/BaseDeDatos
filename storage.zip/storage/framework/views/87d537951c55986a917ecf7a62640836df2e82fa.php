<div>

    <form action="<?php echo e(route('articulos.update',$perfil)); ?>" method="post">
        
        <div class="shadow sm:rounded-md sm:overflow-hidden">
            <div class="bg-white py-6 px-4 sm:p-6">
                <div>
                    <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Información del
                        Artículo</h2>
                    <p class="mt-1 text-sm text-gray-500"></p>
                </div>
                <div class="col-span-4 sm:col-span-1" gap-6>
                    <label for="expiration_date" class="block text-sm font-medium text-gray-700">Título del
                        Artículo</label>
                    <input type="text" name="titulo" id="expiration_date" autocomplete="cc-exp"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                        placeholder="" required value="<?php echo e($perfil->titulo); ?>">
                </div>

                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2">
                        <label for="first_name" class="block text-sm font-medium text-gray-700">DOI</label>
                        <input type="text" name="DOI" id="DOI" autocomplete="cc-given-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->DOI); ?>">
                    </div>

                    <div class="col-span-4 sm:col-span-2">
                        <label for="last_name" class="block text-sm font-medium text-gray-700">Año Publicación</label>
                        <input type="number" name="fecha_publicacion" id="fecha" autocomplete="cc-family-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->fecha_publicacion); ?>">
                    </div>

                    <div class="col-span-4 sm:col-span-2">
                        <label for="last_name" class="block text-sm font-medium text-gray-700">Intervalo de
                            Páginas</label>
                        <input type="text" name="intervalo_paginas" id="intervalo_paginas" autocomplete="cc-family-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->intervalo_paginas); ?>">
                    </div>
                    <div class="col-span-4 sm:col-span-2">
                        <label for="last_name" class="block text-sm font-medium text-gray-700">Issue</label>
                        <input type="text" name="issue" id="issue" autocomplete="cc-family-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->issue); ?>">
                    </div>
                    <div class="col-span-4 sm:col-span-2">
                        <label for="last_name" class="block text-sm font-medium text-gray-700">Volumen</label>
                        <input type="text" name="volumen" id="volumen" autocomplete="cc-family-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->volumen); ?>">
                    </div>


                    <div class="col-span-4 sm:col-span-2">
                        <label for="first_name" class="block text-sm font-medium text-gray-700">Link del artículo en
                            Arxiv</label>
                        <input type="text" name="arxiv" id="arxiv" autocomplete="cc-given-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfil->arxiv); ?>">
                    </div>



                </div>



            </div>
        </div>



        


        <div class="shadow sm:rounded-md sm:overflow-hidden">
            <div class="bg-white py-6 px-4 sm:p-6">
                <div>
                    <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Autores
                    </h2>
                    <p class="mt-1 text-sm text-gray-500"></p>
                </div>

                <div class="mt-6 grid grid-cols-4 gap-6">
                    

                </div>


                <?php $__currentLoopData = $orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-6 grid grid-cols-4 gap-6">
                        <div class="col-span-4 sm:col-span-2 center">
                            
                            <select name="personas[<?php echo e($index); ?>]"
                                wire:model="orderProducts.<?php echo e($index); ?>.product_id"
                                class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">


                                <?php if(isset($orderProduct['id'])): ?>

                                    <option value="<?php echo e($orderProduct['id_Persona']); ?>" selected="selected">
                                        <?php echo e($orderProduct['autor']); ?>

                                    </option>
                                    <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($persona->id == $orderProduct['id']): ?>

                                        <?php else: ?>
                                            <option value="<?php echo e($persona->id); ?>">
                                                <?php echo e($persona->full_name()); ?>


                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <option value="">-- Selecciona Autor -- </option>

                                    <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($persona->id); ?>">
                                            <?php echo e($persona->full_name()); ?>

                                            
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                <?php endif; ?>



                </select>
            </div>


            <div class="col-span-4 sm:col-span-2">
                

                <a href="#" wire:click.prevent="removeProduct(<?php echo e($index); ?>)">
                    <button type="submit"
                        class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Borrar
                    </button>
                </a>
            </div>

        </div>
        &emsp;
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-6 grid grid-cols-4 gap-6">
            <div class="col-span-4 sm:col-span-2">
                <button wire:click.prevent="addProduct"
                    class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">Añadir
                    Autor</button>
            </div>
        </div>


</div>
</div>
<div class="shadow sm:rounded-md sm:overflow-hidden">
    <div class="bg-white py-6 px-4 sm:p-6">
        <div>
            <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Si un autor no
                está en la lista, puedes agregarlo rápido aquí (más tarde puedes editar más detalles de ellos)
            </h2>

        </div>

        <div class="mt-6 grid grid-cols-4 gap-6">
            

        </div>
        <?php $__currentLoopData = $extraPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6 grid grid-cols-4 gap-6">

                
                <div class="col-span-4 sm:col-span-1">
                    <label for="last_name" class="block text-sm font-medium text-gray-700">Primer Nombre</label>
                    <input type="text" name="extraPersonas[<?php echo e($index); ?>][0]"
                        id="extraPersonas[<?php echo e($index); ?>][0]" autocomplete="cc-family-name"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm" required>
                </div>
                <div class="col-span-4 sm:col-span-1">
                    <label for="last_name" class="block text-sm font-medium text-gray-700">Primer
                        Apellido</label>
                    <input type="text" name="extraPersonas[<?php echo e($index); ?>][1]"
                        id="extraPersonas[<?php echo e($index); ?>][1]" autocomplete="cc-family-name"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm" required>
                </div>




                <div class="col-span-4 sm:col-span-2">
                    
                    <label for="last_name" class="block text-sm font-medium text-gray-700">&emsp;</label>
                    <a href="#" wire:click.prevent="removeExtraPersona(<?php echo e($index); ?>)">
                        <button type="submit"
                            class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                            Borrar
                        </button>
                    </a>
                </div>

            </div>
            &emsp;
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="mt-6 grid grid-cols-4 gap-6">
            <div class="col-span-4 sm:col-span-2">
                <button wire:click.prevent="addExtraPersona"
                    class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">Añadir
                    otros
                    Autores</button>
            </div>
        </div>


    </div>
</div>



<div class="shadow sm:rounded-md sm:overflow-hidden">
    <div class="bg-white py-6 px-4 sm:p-6">
        <div>
            <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Revista
            </h2>
            <p class="mt-1 text-sm text-gray-500"></p>
        </div>

        <div class="mt-6 grid grid-cols-4 gap-6">
        </div>

        <div class="col-span-4 sm:col-span-1" gap-6>
            <select name="revista" 
                class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                <?php if(isset($perfil->id_Revista)): ?>

                    <option value="<?php echo e($perfil->id_Revista); ?>" selected><?php echo e($perfil->revista->nombre); ?>

                    </option>

                    <?php $__currentLoopData = $allRevistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($revista->id == $perfil->id_Revista): ?>

                        <?php else: ?>
                            <option value="<?php echo e($revista->id); ?>">
                                <?php echo e($revista->nombre); ?>

                                
                            </option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option value="">-- Selecciona la Revista --</option>

                    <?php $__currentLoopData = $allRevistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($revista->id); ?>">
                            <?php echo e($revista->nombre); ?>

                            
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>

        </div>
    </div>
</div>



<div class="shadow sm:rounded-md sm:overflow-hidden">
    <div class="bg-white py-6 px-4 sm:p-6">
        <div class="col-span-4 sm:col-span-1" gap-6>
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Información
                    extra
                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>
            <label for="expiration_date" class="block text-sm font-medium text-gray-700"></label>
            <input type="text" name="descripcion" id="descripcion" autocomplete="cc-exp"
                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                placeholder="" value="<?php echo e($perfil->descripcion); ?>">
        </div>


    </div>
</div>
<div class="px-4 py-3 bg-gray-50 text-right sm:px-6">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <button type="submit"
        class="bg-gray-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
        Editar Artículo
    </button>
</div>
</div>
</form>

</div>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/livewire/editar/articulos.blade.php ENDPATH**/ ?>