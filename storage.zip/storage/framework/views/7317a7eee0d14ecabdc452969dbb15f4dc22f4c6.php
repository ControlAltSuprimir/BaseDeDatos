<form action="<?php echo e(route('tesis.update',$perfil->id)); ?>" method="POST">
    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">Información
                    de la Tesis</h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>
            <div class="col-span-4 sm:col-span-1" gap-6>
                <label for="expiration_date" class="block text-sm font-medium text-gray-700">Título</label>
                <input type="text" name="titulo" id="expiration_date" autocomplete="cc-exp"
                    class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                    placeholder="" value="<?php echo e($perfil->titulo); ?>" required>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
                <div class="col-span-4 sm:col-span-2">
                    <label for="first_name" class="block text-sm font-medium text-gray-700">Fecha de
                        Defensa</label>
                    <input type="date" name="fechaDefensa" id="fechaDefensa" autocomplete="cc-given-name"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                        value="<?php echo e($perfil->fechaDefensa); ?>">
                </div>

                <div class="col-span-4 sm:col-span-2">
                    <label for="last_name" class="block text-sm font-medium text-gray-700"> </label>
                    
                </div>



            </div>



        </div>
    </div>


    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Autor(a) de la Tesis
                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <div class="col-span-4 sm:col-span-1" gap-6>
                <select name="autor" id="autor"  wire:model="autor" 
                    class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                    <option value="">-- Selecciona la Persona --</option>

                    <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($persona->id); ?>">
                            <?php echo e($persona->full_name()); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>
    </div>


    


    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Tutor(a) de la Tesis
                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <div class="col-span-4 sm:col-span-1" gap-6>
                <select name="tutor" id="tutor" wire:model="tutor" 
                    class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                    <option value="">-- Selecciona la Persona --</option>

                    <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($persona->id); ?>">
                            <?php echo e($persona->full_name()); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>
    </div>


    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Cotutores de la Tesis

                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <?php $__currentLoopData = $cotutores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2 center">
                        
                        <select name="cotutores[<?php echo e($index); ?>]" wire:model="cotutores.<?php echo e($index); ?>"
                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                            <option value="">-- Selecciona la Persona -- </option>

                            <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($persona->id); ?>">
                                    <?php echo e($persona->full_name()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="col-span-4 sm:col-span-2">
                        

                        <a href="#" wire:click.prevent="removeItem(<?php echo e($index); ?>,'cotutores')">
                            <button type="submit"
                                class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                                Borrar
                            </button>
                        </a>
                    </div>

                </div>
                &emsp;
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6 grid grid-cols-4 gap-6">
                <div class="col-span-4 sm:col-span-2">
                    <button wire:click.prevent="addItem('cotutores')"
                        class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Añadir Cotutor
                    </button>
                </div>
            </div>
        </div>
    </div>

    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Programa Asociado
                </h2>
                <p class="mt-1 text-sm text-gray-500">Si el programa no está en la base de datos, agrégalo aquí.</p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <div class="col-span-4 sm:col-span-1" gap-6>
                <select name="programa" id="programa" wire:model="programa"
                    class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                    <option value="">-- Selecciona el Programa --</option>

                    <?php $__currentLoopData = $allProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($programa->id); ?>">
                            <?php echo e($programa->nombre); ?>.  <?php echo e($programa->institucion->nombre); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
        </div>
    </div>

    <?php
    //echo $programaSeleccionado;
    $arrayProgramas = [1, 2, 3, 4];
    ?>

    <?php if(in_array($programa->id, $arrayProgramas)): ?>
        <div class="shadow sm:rounded-md sm:overflow-hidden">
            <div class="bg-white py-6 px-4 sm:p-6">
                

                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2">
                        <label for="first_name" class="block text-sm font-medium text-gray-700">
                            Fecha de Proyecto
                        </label>
                        <input type="date" name="fechaProyecto" id="fechaProyecto" autocomplete="cc-given-name"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                            value="<?php echo e($perfilInterno->fechaProyecto); ?>">
                    </div>

                    <div class="col-span-4 sm:col-span-2">
                        <label for="last_name" class="block text-sm font-medium text-gray-700"> 
                            Estado
                        </label>
                        <input type="text" name="estado" id="estado" autocomplete="cc-family-name"
                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                        placeholder="En proceso, " 
                        value="<?php echo e($perfilInterno->estado); ?>">
                    </div>



                </div>



            </div>
        </div>
    <?php else: ?>
         

    <?php endif; ?>

    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Jurado de la Tesis

                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <?php $__currentLoopData = $comision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2 center">
                        
                        <select name="comision[<?php echo e($index); ?>]" wire:model="comision.<?php echo e($index); ?>"
                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                            <option value="">-- Selecciona la Persona -- </option>

                            <?php $__currentLoopData = $allPersonas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($persona->id); ?>">
                                    <?php echo e($persona->full_name()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="col-span-4 sm:col-span-2">
                        

                        <a href="#" wire:click.prevent="removeItem(<?php echo e($index); ?>,'comision')">
                            <button type="submit"
                                class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                                Borrar
                            </button>
                        </a>
                    </div>

                </div>
                &emsp;
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6 grid grid-cols-4 gap-6">
                <div class="col-span-4 sm:col-span-2">
                    <button wire:click.prevent="addItem('comision')"
                        class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Añadir Miembro de Comisión
                    </button>
                </div>
            </div>
        </div>
    </div>

    <hr>

    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Artículos relacionados con la Tesis

                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2 center">
                        
                        <select name="articulos[<?php echo e($index); ?>]" wire:model="articulos.<?php echo e($index); ?>"
                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                            <option value="">-- Selecciona el Artículo -- </option>

                            <?php $__currentLoopData = $allArticulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($articulo->id); ?>">
                                    <?php echo e($articulo->titulo); ?>. Autores: <?php echo e($articulo->autoresNoLink()); ?>.
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="col-span-4 sm:col-span-2">
                        

                        <a href="#" wire:click.prevent="removeItem(<?php echo e($index); ?>,'articulos')">
                            <button type="submit"
                                class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                                Borrar
                            </button>
                        </a>
                    </div>

                </div>
                &emsp;
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6 grid grid-cols-4 gap-6">
                <div class="col-span-4 sm:col-span-2">
                    <button wire:click.prevent="addItem('articulos')"
                        class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Añadir Artículos
                    </button>
                </div>
            </div>
        </div>
    </div>



    <hr>
    

    <div class="shadow sm:rounded-md sm:overflow-hidden">
        <div class="bg-white py-6 px-4 sm:p-6">
            <div>
                <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                    Proyectos relacionados con la Tesis

                </h2>
                <p class="mt-1 text-sm text-gray-500"></p>
            </div>

            <div class="mt-6 grid grid-cols-4 gap-6">
            </div>

            <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $orderProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-6 grid grid-cols-4 gap-6">
                    <div class="col-span-4 sm:col-span-2 center">
                        
                        <select name="proyectos[<?php echo e($index); ?>]" wire:model="proyectos.<?php echo e($index); ?>"
                            class="mt-1 block w-full bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm">
                            <option value="">-- Selecciona el Proyecto -- </option>

                            <?php $__currentLoopData = $allProyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($proyecto->id); ?>">
                                    <?php echo e($proyecto->full_name()); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>


                    <div class="col-span-4 sm:col-span-2">
                        

                        <a href="#" wire:click.prevent="removeItem(<?php echo e($index); ?>,'proyectos')">
                            <button type="submit"
                                class="bg-red-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                                Borrar
                            </button>
                        </a>
                    </div>

                </div>
                &emsp;
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="mt-6 grid grid-cols-4 gap-6">
                <div class="col-span-4 sm:col-span-2">
                    <button wire:click.prevent="addItem('proyectos')"
                        class="bg-green-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-green-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Añadir Proyecto
                    </button>
                </div>
            </div>
        </div>
    </div>



    <hr>
    <div class="px-4 py-3 bg-gray-50 text-right sm:px-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <button type="submit"
            class="bg-gray-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
            Añadir Tesis
        </button>
    </div>

</form>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/livewire/editar/tesis.blade.php ENDPATH**/ ?>