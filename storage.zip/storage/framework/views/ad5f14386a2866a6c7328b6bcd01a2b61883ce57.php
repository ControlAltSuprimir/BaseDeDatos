<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                Añadir Artículo
            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">

        </div>
    </div>
    <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-9">


        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('crear.creararticulo')->html();
} elseif ($_instance->childHasBeenRendered('8UqiBO9')) {
    $componentId = $_instance->getRenderedChildComponentId('8UqiBO9');
    $componentTag = $_instance->getRenderedChildComponentTagName('8UqiBO9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8UqiBO9');
} else {
    $response = \Livewire\Livewire::mount('crear.creararticulo');
    $html = $response->html();
    $_instance->logRenderedChild('8UqiBO9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/articulos/create.blade.php ENDPATH**/ ?>