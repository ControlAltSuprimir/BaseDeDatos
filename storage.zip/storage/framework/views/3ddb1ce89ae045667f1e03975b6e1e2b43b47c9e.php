<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- Page title & actions -->
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                Proyectos
            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">
            
            <a href="/proyectos/create">
                <button type="button"
                    class="order-0 inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 sm:order-1 sm:ml-3">
                    Añadir Proyecto
                </button>
            </a>
        </div>
    </div>
    <!-- Pinned projects -->


    <!-- Projects list (only on smallest breakpoint) -->


    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('tablas.proyecto')->html();
} elseif ($_instance->childHasBeenRendered('2Do5ED1')) {
    $componentId = $_instance->getRenderedChildComponentId('2Do5ED1');
    $componentTag = $_instance->getRenderedChildComponentTagName('2Do5ED1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2Do5ED1');
} else {
    $response = \Livewire\Livewire::mount('tablas.proyecto');
    $html = $response->html();
    $_instance->logRenderedChild('2Do5ED1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/proyectos/index.blade.php ENDPATH**/ ?>