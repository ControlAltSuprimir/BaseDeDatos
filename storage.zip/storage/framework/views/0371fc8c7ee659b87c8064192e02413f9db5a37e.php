<div>

    <section aria-labelledby="payment_details_heading">
        <form action="<?php echo e(route('indexaciones.update', $edit)); ?>" method="POST">

            <div class="shadow sm:rounded-md sm:overflow-hidden">
                <div class="bg-white py-6 px-4 sm:p-6">
                    <div>
                        <h2 id="payment_details_heading" class="text-lg leading-6 font-medium text-gray-900">
                            Información Principal</h2>
                        <p class="mt-1 text-sm text-gray-500"></p>
                    </div>

                    <div class="mt-6 grid grid-cols-4 gap-6">
                        <div class="col-span-4 sm:col-span-2">
                            <label for="first_name" class="block text-sm font-medium text-gray-700">Nombre de la
                                Indexación</label>
                            <input type="text" name="nombre" id="first_name" autocomplete="cc-given-name"
                                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-gray-900 focus:border-gray-900 sm:text-sm"
                                value="<?php echo e($perfil->nombre); ?>">
                        </div>




                    </div>
                </div>

                <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-9">

                </div>
                <div class="px-4 py-3 bg-gray-50 text-right sm:px-6">
                    <?php echo csrf_field(); ?>

                    <?php echo method_field('PUT'); ?>
                    <button type="submit"
                        class="bg-gray-800 border border-transparent rounded-md shadow-sm py-2 px-4 inline-flex justify-center text-sm font-medium text-white hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900">
                        Actualizar Indexación
                    </button>
                </div>
            </div>
        </form>
    </section>



    

</div>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/livewire/editar/indexacion.blade.php ENDPATH**/ ?>