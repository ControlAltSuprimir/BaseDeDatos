<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="border-b border-gray-200 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:px-6 lg:px-8">
        <div class="flex-1 min-w-0">
            <h1 class="text-lg font-medium leading-6 text-gray-900 sm:truncate">
                Editar Revista
            </h1>
        </div>
        <div class="mt-4 flex sm:mt-0 sm:ml-4">

        </div>
    </div>
    <?php $edit = $data['id']; ?>
    <div class="space-y-6 sm:px-6 lg:px-0 lg:col-span-9">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('editar.editararticulo',['edit'=>$edit])->html();
} elseif ($_instance->childHasBeenRendered('XTSZPBO')) {
    $componentId = $_instance->getRenderedChildComponentId('XTSZPBO');
    $componentTag = $_instance->getRenderedChildComponentTagName('XTSZPBO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XTSZPBO');
} else {
    $response = \Livewire\Livewire::mount('editar.editararticulo',['edit'=>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('XTSZPBO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



        <?php // $edit=$data['id'];?>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('borrar.borrar_articulo',['edit' =>$edit])->html();
} elseif ($_instance->childHasBeenRendered('fYXnOiI')) {
    $componentId = $_instance->getRenderedChildComponentId('fYXnOiI');
    $componentTag = $_instance->getRenderedChildComponentTagName('fYXnOiI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fYXnOiI');
} else {
    $response = \Livewire\Livewire::mount('borrar.borrar_articulo',['edit' =>$edit]);
    $html = $response->html();
    $_instance->logRenderedChild('fYXnOiI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

    
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\BaseDeDatos\resources\views/articulos/edit.blade.php ENDPATH**/ ?>