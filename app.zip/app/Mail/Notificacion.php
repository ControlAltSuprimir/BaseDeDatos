<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

//Para enviar correo
use Illuminate\Support\Facades\Mail;

class Notificacion extends Mailable
{
    use Queueable, SerializesModels;

    public $subject = "Notificación";

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('mail.notificacion');
    }

    public function nuevoUsuario()
    {
        $correo = new Notificacion;
        $correo->subject="Nuevo Usuario";
        Mail::to('jaure.diego@gmail.com')->send($correo);

        return "Mensaje Enviado";
    }
}
